import styles from '../styles/final.module.css';

function Final() {
  return (
    <>
      <div className={styles.finalpage}>
        <div className={styles.final}>
          <h2>CONGRATULATIONS!</h2>
          <h3>Successfully Redeemed</h3>
          <p>
            Congratilation! You just obtained (Free Rewards) ,reward will be
            sent in 24hours to your account.
          </p>
        </div>
      </div>
    </>
  );
}

export default Final;
